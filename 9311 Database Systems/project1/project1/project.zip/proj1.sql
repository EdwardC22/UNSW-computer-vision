-- comp9311 21T1 Project 1 sql part
--
-- MyMyUNSW Solutions


-- Q1:
create or replace view Q1(subject_longname, subject_num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q2:
create or replace view Q2(OrgUnit_id, OrgUnit, OrgUnit_type, Program)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q3:
create or replace view Q3(course,student_num,avg_mark)
as 
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q4:
create or replace view Q4(student_num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

--Q5:
create or replace view Q5(unswid, min_mark, course)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q6:
create or replace view Q6(course_id)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q7:
create or replace view Q7(staff_name, semester, course_num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q8: 
create or replace view Q8(role_id, role_name, num_students)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q9:
create or replace view Q9(year, term, stype, average_mark)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q10:
create or replace view Q10(room, capacity, num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q11:
create or replace view Q11(staff, subject, num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q12:
create or replace view Q12(staff, role, hd_rate)
as
--... SQL statements, possibly using other views/functions defined by you ...
;
